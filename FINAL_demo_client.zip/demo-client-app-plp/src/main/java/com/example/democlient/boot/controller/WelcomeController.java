package com.example.democlient.boot.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.request;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.example.democlient.boot.beans.Admin;
import com.example.democlient.boot.beans.Customer;
import com.example.democlient.boot.beans.Merchant;
import com.example.democlient.boot.beans.User;
import com.example.democlient.boot.repo.userDAO;

@Controller
@RequestMapping("/controller")
public class WelcomeController {

	@Autowired
	userDAO userDAO;

	// inject via application.properties
	/*
	 * @Value("${welcome.message:test}") private String message = "Hello World";
	 * 
	 * @RequestMapping("/") public String welcome(Map<String, Object> model) {
	 * model.put("message", this.message); return "welcome"; }
	 */

	@RequestMapping(method = RequestMethod.GET, value = "/login")
	public String getResponse() {

		return "login";

	}

	@RequestMapping(method = RequestMethod.POST, value = "/validateuser")
	public String validateUser(@ModelAttribute("userlogin") User user, HttpServletRequest request) {
		HttpSession session=null;
		boolean flag = userDAO.validateUser(user);
		String email=user.getEmailId();
		if (flag) {
			session = request.getSession();
		}
		if (flag && user.getRole().equalsIgnoreCase("Merchant")) {
			System.out.println("mer");
			Merchant a = userDAO.getMerchantByEmail(email);
			session.setAttribute("userid", a.getMerchantId());
			System.out.println(a.getMerchantId());
			
			
		} else if (flag && user.getRole().equalsIgnoreCase("Customer")) {
			System.out.println("cu");
			Customer a = userDAO.getCustomerByEmail(email);
			session.setAttribute("userid", a.getCustomerId());
			System.out.println(a.getCustomerId());

		} else if (flag && user.getRole().equalsIgnoreCase("Admin")) {
			System.out.println("ad");
			Admin a = userDAO.getAdminByEmail(email);
			session.setAttribute("userid", a.getAdminId());
			System.out.println(a.getAdminId());
		}
		else
		{
			request.setAttribute("errormsg", "wrong");
			return "login";
		}

		return "subhanshu";

	}

	@RequestMapping(method = RequestMethod.GET, value = "/role")
	public String role() {
		return "role";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/registerMerchant")
	public String registerMerchant() {
		// RestTemplate restTemplate = new RestTemplate();
		// userDAO.save(user);
		return "registerMerchant";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveMerchant")
	public String saveMerchant(@ModelAttribute("merchant") Merchant mer, @RequestParam("password") String pass1) {

		User user = new User();
		user.setEmailId(mer.getMerchantEmail());
		user.setPassword(pass1);
		user.setRole("merchant");
		userDAO.createMerchant(mer);
		userDAO.createUser(user);
		return "login";
	}

	@RequestMapping(method = RequestMethod.GET, value = "/registerCustomer")
	public String registerCustomer() {
		return "registerCustomer";
	}

	@RequestMapping(method = RequestMethod.POST, value = "/saveCustomer")
	public String saveCustomer(@ModelAttribute("customer") Customer cust, @RequestParam("password") String pass) {
		User user = new User();

		user.setEmailId(cust.getCustomerEmail());
		user.setPassword(pass);
		user.setRole("customer");
		userDAO.createCustomer(cust);
		userDAO.createUser(user);
		return "login";
	}
	@RequestMapping(method = RequestMethod.GET, value = "/change")
	public String forget() {
		return "changepass2";
		
	}

	@RequestMapping(method = RequestMethod.GET, value = "/forget")
	public String forget(@ModelAttribute("forget") User user) {
		return "forget";
		
	}

	@RequestMapping(method = RequestMethod.POST, value = "/form")
	public String forget(@RequestParam("mail")String email) {
		String s=userDAO.forgetEmail(email);
		File file = new File("D:\\Training\\final_project\\demo-client-updated.zip_expanded\\demo-client-app-plp\\text\\password.txt");
		FileWriter fileWriter;
		try {
			fileWriter = new FileWriter(file.getAbsoluteFile(),true);
			fileWriter.write("Your Password is: "+s);
			fileWriter.flush();
			fileWriter.close();			
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		
				
		
		return "login";}
		
	
	@RequestMapping(method = RequestMethod.POST, value = "/changepass")
	public String change(@ModelAttribute("change") User user) {
		System.out.println("hello"+user);
		userDAO.changePassword(user);
		
		
		return "password changed";
	}

	@ModelAttribute("merchant")
	public Merchant createMerchant() {
		return new Merchant();
	}

	@ModelAttribute("userlogin")
	public User Userlogin() {
		return new User();
	}

	@ModelAttribute("customer")
	public Customer createCustomer() {
		return new Customer();
	}
	
	@ModelAttribute("forget")
	public User ForgetUser() {
		return new User();
	}
	
	@ModelAttribute("change")
	public User ChangePass() {
		return new User();
	}
}
